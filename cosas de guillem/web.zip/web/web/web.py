"""Welcome to Reflex! This file outlines the steps to create a basic app."""
import reflex as rx
from rxconfig import config

from .componets.sidebar import sidebar_bottom_profile
from .pages.principal import center_container
from .pages.llista import llistat
from .pages.afegir import afegir_producte
from .pages.consular import consultar_producte
from .cotrollers.llistastate import LlistaState
from .cotrollers.consultarstate import ConsultarState

def index() -> rx.Component:
    # Welcome Page (Index)
    return rx.hstack(
        sidebar_bottom_profile(),
        center_container(),        
    )

def llista() -> rx.Component:
    return rx.hstack(
        sidebar_bottom_profile(),
        llistat(),        
    )

def afegir() -> rx.Component:
    return rx.hstack(
        sidebar_bottom_profile(),
        afegir_producte()
    )

def consultar() -> rx.Component:
    return rx.hstack(
        sidebar_bottom_profile(),
        consultar_producte()
    )

app = rx.App()
app.add_page(index)
app.add_page(llista, route="llistat", on_load=LlistaState.get_products)
app.add_page(afegir, route="afegir")
app.add_page(consultar, route="consular/[codi]", on_load=ConsultarState.get_product)
