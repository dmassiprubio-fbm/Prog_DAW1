import reflex as rx
from ..cotrollers.principalstate import PrincipalState

def _render_alumne(alumne:str) -> rx.Component:
    return rx.text(alumne,  color=PrincipalState.color)

def center_container() -> rx.Component:
    return rx.container(
            rx.color_mode.button(position="bottom-right"),
            rx.vstack(
                rx.heading("Welcome to " + PrincipalState.text +"!", size="9"),  
                rx.heading("A PTD II", size="5"),
                rx.link("A la pàgina primera", href="/primera", target="_blank"),
                rx.input(
                    default_value=PrincipalState.text,
                    on_change=PrincipalState.update_text,
                ),
                rx.input(
                    default_value=PrincipalState.text,
                    on_blur=PrincipalState.update_text,
                ),
                rx.hstack(
                    rx.button("Click Me + 1",size="4",border_radius="50px", on_click=lambda: PrincipalState.increment(1)),
                    rx.button("Click Me + 5",size="4",border_radius="50px", on_click=lambda: PrincipalState.increment(5)),  
                    rx.text(PrincipalState.count, color=PrincipalState.color, font_size = "40px"),
                    rx.button("Reset",size="4",border_radius="50px", on_click=PrincipalState.reset_count),
                    align="center"
                ),
                rx.box(
                    rx.foreach(PrincipalState.alumnes, _render_alumne)
                ),   
                rx.hstack(
                    rx.cond(
                        PrincipalState.color == "red",
                        rx.text("Color vermell"),
                        rx.text("Color verd")
                    ),
                    align="center"   
                ),         
                spacing="5",          
                justify="center",
                align="center",
                min_height="85vh",
            ),        
            rx.logo(),
        ),