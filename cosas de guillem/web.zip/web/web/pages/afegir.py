import reflex as rx
from ..cotrollers.afegirstate import AfegirState

def form_add_product():
    return rx.vstack(
            rx.form(
                rx.vstack(
                    rx.input(
                        placeholder="Codi",
                        name="codi_product",
                    ),
                    rx.input(
                        placeholder="Nom",
                        name="nom_product",
                    ),
                    rx.input(
                        placeholder="Preu",
                        name="preu_product",
                    ),
                    rx.button("Afegir", type="submit"),
                ),
                on_submit=AfegirState.handle_submit,
                reset_on_submit=True,
            ),
    )

def afegir_producte() -> rx.Component:
    return rx.container(
            rx.vstack(
                rx.heading("afegir"),
                form_add_product(),
            )            
        ),