import reflex as rx

class PrincipalState(rx.State):
    count: int = 0
    color: str = "red"
    text: str = "Guillem"
    alumnes: list[str] = ["Dani", "Falilou", "Mati", "Alba", "Carlos", "Damià", "Houssam"]
    
    @rx.event
    def increment(self, value):
        self.count += value
        if self.count % 2 == 0:
            self.color = "green"
        else:
            self.color = "red"

    @rx.event
    def reset_count(self):
        self.count = 0

    @rx.event
    def update_text(self, new_text: str):
        self.text = new_text